export class Book{
    id:number;
    title:string;
    year:number;
    author:string;
}
